// routes/calculator.js
// -----------------------------------------------------------------------
// Define los endpoints REST que consumirá el frontend Angular.
// -----------------------------------------------------------------------

const express = require('express');
const router = express.Router();
const calculatorModel = require('../models/calculatorModel');

// POST /api/calculator/calcular
// body: { numero1: number, numero2: number, operacion: string }
router.post('/calcular', (req, res) => {
  try {
    const numero1 = Number(req.body.numero1);
    const numero2 = Number(req.body.numero2);
    const { operacion } = req.body;

    const registro = calculatorModel.ejecutarOperacion(numero1, numero2, operacion);
    res.status(200).json(registro);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// GET /api/calculator/historial
router.get('/historial', (req, res) => {
  const historial = calculatorModel.obtenerHistorial();
  res.status(200).json(historial);
});

// DELETE /api/calculator/historial
router.delete('/historial', (req, res) => {
  const historial = calculatorModel.limpiarHistorial();
  res.status(200).json(historial);
});

module.exports = router;
