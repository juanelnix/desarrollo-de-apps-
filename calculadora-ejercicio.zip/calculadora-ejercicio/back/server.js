// server.js
const express = require('express');
const cors = require('cors');
const calculatorRoutes = require('./routes/calculator');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.use('/api/calculator', calculatorRoutes);

app.get('/', (req, res) => {
  res.send('API Calculadora funcionando. Prueba /api/calculator/historial');
});

app.listen(PORT, () => {
  console.log(`Servidor backend escuchando en http://localhost:${PORT}`);
});
