// db.js
// -----------------------------------------------------------------------
// Este archivo es el "engine" de persistencia. Usamos lowdb, una base de
// datos ligera basada en un archivo JSON. Cualquier módulo que necesite
// leer o escribir datos importa este archivo, en vez de tocar el archivo
// JSON directamente. Así, si el día de mañana se cambia lowdb por
// MongoDB, PostgreSQL, etc., solo se modifica este archivo.
// -----------------------------------------------------------------------

const path = require('path');
const low = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync');

const file = path.join(__dirname, '..', 'data', 'history.json');
const adapter = new FileSync(file);
const db = low(adapter);

// Estructura inicial de la base de datos si el archivo está vacío
db.defaults({ history: [] }).write();

module.exports = db;
