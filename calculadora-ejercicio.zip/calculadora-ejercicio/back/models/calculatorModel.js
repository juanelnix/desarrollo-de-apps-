// calculatorModel.js
// -----------------------------------------------------------------------
// Modelo de la calculadora. Contiene:
//  1) La lógica de las operaciones matemáticas.
//  2) El acceso al "engine" (db.js) para guardar y leer el historial.
// Las rutas (controllers) nunca acceden a db.js directamente, siempre
// pasan por este modelo. Esto separa responsabilidades (patrón MVC).
// -----------------------------------------------------------------------

const { v4: uuidv4 } = require('uuid');
const db = require('./db');

const OPERACIONES_VALIDAS = ['suma', 'resta', 'multiplicacion', 'division'];

/**
 * Ejecuta la operación matemática indicada sobre dos números.
 * @param {number} numero1
 * @param {number} numero2
 * @param {string} operacion - suma | resta | multiplicacion | division
 * @returns {number} resultado
 */
function calcular(numero1, numero2, operacion) {
  switch (operacion) {
    case 'suma':
      return numero1 + numero2;
    case 'resta':
      return numero1 - numero2;
    case 'multiplicacion':
      return numero1 * numero2;
    case 'division':
      if (numero2 === 0) {
        throw new Error('No se puede dividir entre cero');
      }
      return numero1 / numero2;
    default:
      throw new Error(`Operación no soportada: ${operacion}`);
  }
}

/**
 * Valida y ejecuta una operación, guardando el resultado en el historial.
 */
function ejecutarOperacion(numero1, numero2, operacion) {
  if (typeof numero1 !== 'number' || typeof numero2 !== 'number' || Number.isNaN(numero1) || Number.isNaN(numero2)) {
    throw new Error('numero1 y numero2 deben ser números válidos');
  }
  if (!OPERACIONES_VALIDAS.includes(operacion)) {
    throw new Error(`Operación inválida. Usa una de: ${OPERACIONES_VALIDAS.join(', ')}`);
  }

  const resultado = calcular(numero1, numero2, operacion);

  const registro = {
    id: uuidv4(),
    numero1,
    numero2,
    operacion,
    resultado,
    fecha: new Date().toISOString(),
  };

  db.get('history').push(registro).write();

  return registro;
}

function obtenerHistorial() {
  // Se devuelve del más reciente al más antiguo
  return db.get('history').orderBy(['fecha'], ['desc']).value();
}

function limpiarHistorial() {
  db.set('history', []).write();
  return [];
}

module.exports = {
  OPERACIONES_VALIDAS,
  ejecutarOperacion,
  obtenerHistorial,
  limpiarHistorial,
};
