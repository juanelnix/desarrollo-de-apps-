import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface OperacionResultado {
  id: string;
  numero1: number;
  numero2: number;
  operacion: string;
  resultado: number;
  fecha: string;
}

@Injectable({
  providedIn: 'root',
})
export class CalculatorService {
  // Ajusta esta URL si tu backend corre en otro host/puerto
  private apiUrl = 'http://localhost:3000/api/calculator';

  constructor(private http: HttpClient) {}

  calcular(numero1: number, numero2: number, operacion: string): Observable<OperacionResultado> {
    return this.http.post<OperacionResultado>(`${this.apiUrl}/calcular`, {
      numero1,
      numero2,
      operacion,
    });
  }

  obtenerHistorial(): Observable<OperacionResultado[]> {
    return this.http.get<OperacionResultado[]>(`${this.apiUrl}/historial`);
  }

  limpiarHistorial(): Observable<OperacionResultado[]> {
    return this.http.delete<OperacionResultado[]>(`${this.apiUrl}/historial`);
  }
}
