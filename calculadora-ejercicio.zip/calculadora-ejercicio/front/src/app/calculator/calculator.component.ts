import { Component, OnInit } from '@angular/core';
import { CalculatorService, OperacionResultado } from '../services/calculator.service';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css'],
})
export class CalculatorComponent implements OnInit {
  numero1: number | null = null;
  numero2: number | null = null;
  operacion: string = 'suma';

  resultado: number | null = null;
  error: string | null = null;
  cargando = false;

  historial: OperacionResultado[] = [];

  operaciones = [
    { valor: 'suma', etiqueta: 'Suma (+)' },
    { valor: 'resta', etiqueta: 'Resta (-)' },
    { valor: 'multiplicacion', etiqueta: 'Multiplicación (×)' },
    { valor: 'division', etiqueta: 'División (÷)' },
  ];

  constructor(private calculatorService: CalculatorService) {}

  ngOnInit(): void {
    this.cargarHistorial();
  }

  calcular(): void {
    this.error = null;
    this.resultado = null;

    if (this.numero1 === null || this.numero2 === null) {
      this.error = 'Debes ingresar ambos números';
      return;
    }

    this.cargando = true;
    this.calculatorService.calcular(this.numero1, this.numero2, this.operacion).subscribe({
      next: (registro) => {
        this.resultado = registro.resultado;
        this.historial.unshift(registro);
        this.cargando = false;
      },
      error: (err) => {
        this.error = err?.error?.error || 'Ocurrió un error al calcular';
        this.cargando = false;
      },
    });
  }

  cargarHistorial(): void {
    this.calculatorService.obtenerHistorial().subscribe({
      next: (data) => (this.historial = data),
      error: () => (this.error = 'No se pudo cargar el historial'),
    });
  }

  limpiarHistorial(): void {
    this.calculatorService.limpiarHistorial().subscribe({
      next: (data) => (this.historial = data),
      error: () => (this.error = 'No se pudo limpiar el historial'),
    });
  }

  simboloOperacion(operacion: string): string {
    const simbolos: { [clave: string]: string } = {
      suma: '+',
      resta: '-',
      multiplicacion: '×',
      division: '÷',
    };
    return simbolos[operacion] || operacion;
  }
}
