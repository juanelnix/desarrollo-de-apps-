# Ejercicio: Calculadora con Node.js + Angular

Calculadora con **numero1**, **numero2**, selección de **operación**,
**resultado** e **historial** persistido en un "engine" de datos (lowdb,
basado en JSON) del lado del backend.

## Arquitectura

```
calculadora-ejercicio/
├── backend/                  Node.js + Express (API REST)
│   ├── server.js             Punto de entrada del servidor
│   ├── routes/
│   │   └── calculator.js     Endpoints /api/calculator/*
│   ├── models/
│   │   ├── calculatorModel.js  Lógica de negocio (operaciones + historial)
│   │   └── db.js               "Engine" de persistencia (lowdb sobre JSON)
│   └── data/
│       └── history.json      Archivo donde se guarda el historial
│
└── frontend/                 Angular (solo los archivos del componente)
    └── src/app/
        ├── app.module.ts
        ├── app.component.ts
        ├── services/
        │   └── calculator.service.ts   Llamadas HTTP al backend
        └── calculator/
            ├── calculator.component.ts
            ├── calculator.component.html
            └── calculator.component.css
```

## 1. Backend (Node.js)

```bash
cd backend
npm install
npm start
```

El servidor queda escuchando en `http://localhost:3000`.

### Endpoints

| Método | Ruta                          | Descripción                        |
|--------|-------------------------------|-------------------------------------|
| POST   | /api/calculator/calcular      | Body: `{ numero1, numero2, operacion }` |
| GET    | /api/calculator/historial     | Devuelve el historial completo      |
| DELETE | /api/calculator/historial     | Limpia el historial                 |

Operaciones válidas: `suma`, `resta`, `multiplicacion`, `division`.

Prueba rápida con curl:

```bash
curl -X POST http://localhost:3000/api/calculator/calcular \
  -H "Content-Type: application/json" \
  -d '{"numero1": 10, "numero2": 5, "operacion": "suma"}'
```

## 2. Frontend (Angular)

Este ejercicio incluye solo los archivos "de negocio" del proyecto Angular
(componente, servicio y módulo), no el andamiaje completo del CLI. Para
integrarlo:

```bash
# Si no tienes un proyecto Angular todavía:
npm install -g @angular/cli
ng new frontend --routing=false --style=css
cd frontend
```

Luego copia el contenido de la carpeta `frontend/src/app` de este
ejercicio dentro del `src/app` de tu proyecto Angular generado
(reemplazando `app.module.ts` y `app.component.ts`), y ejecuta:

```bash
ng serve -o
```

La app quedará en `http://localhost:4200` y consumirá el backend en
`http://localhost:3000` (revisa `apiUrl` en `calculator.service.ts` si
cambias el puerto).

## Cómo está pensado el "engine model"

- **db.js** es el motor de persistencia: es el único archivo que sabe que
  los datos viven en un JSON manejado por lowdb. Si más adelante quieres
  cambiar a MongoDB o SQLite, solo tocas este archivo.
- **calculatorModel.js** es el modelo: valida los datos, ejecuta las
  operaciones matemáticas y decide qué se guarda en el historial. No sabe
  nada de HTTP.
- **routes/calculator.js** es el controlador: solo traduce peticiones HTTP
  a llamadas del modelo y responde con JSON.

## Posibles extensiones (para practicar más)

- Agregar operación de potencia y raíz cuadrada.
- Guardar el historial por usuario (con un login simple).
- Migrar el "engine" de lowdb a MongoDB con Mongoose.
- Agregar tests unitarios al modelo con Jest.
- Paginar el historial en el frontend.
